https://unece.org/sites/default/files/2023-10/XMLNamingAndDesignRulesV2.1.1.pdf

[R205] If a coupled design approach is used, then the qdt:QualifiedDataType schema module MUST import all 
code list and identifier scheme schemas used in the module. 